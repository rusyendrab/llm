from bs4 import BeautifulSoup
from urllib.parse import urljoin


class HyperlinkExtractorTool:

    def __init__(self, base_url):
        self.base_url = base_url

    def extract_hyperlinks(self, content):
        # Parse content using BeautifulSoup
        soup = BeautifulSoup(content, 'html.parser')

        # Find all image and anchor tags
        links = []

        # Extract images (img) and their source URLs
        for img in soup.find_all('img'):
            src = img.get('src')
            if src:
                absolute_url = urljoin(self.base_url, src)
                links.append(absolute_url)

        # Extract anchor tags (a) and their href URLs
        for a in soup.find_all('a'):
            href = a.get('href')
            if href:
                absolute_url = urljoin(self.base_url, href)
                links.append(absolute_url)

        return links


# Example usage of the tool
base_url = "https://example.com"
content = """
    <html>
        <body>
            <img src="/images/sample.jpg" />
            <a href="/downloads/sample.pdf">Download</a>
        </body>
    </html>
"""

extractor_tool = HyperlinkExtractorTool(base_url)
links = extractor_tool.extract_hyperlinks(content)

# Output the extracted absolute hyperlinks
print(links)
