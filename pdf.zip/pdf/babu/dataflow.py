import openai
from graphviz import Digraph

# Set your OpenAI API key
openai.api_key = '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'

# Define the messages for the chat completion
messages = [
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": """
Create a detailed description of a data pipeline with the following components:
1. Data Sources: MySQL, REST API
2. Data Ingestion: Apache Kafka, Apache Nifi
3. Data Storage: AWS S3, Snowflake
4. Data Processing: Apache Spark, AWS Lambda
5. Data Analytics: Tableau, Power BI
Describe how data flows between these components and include any necessary details.
    """}
]

# Generate the description using GPT-4
response = openai.ChatCompletion.create(
    model="gpt-4",  # You can also use "gpt-3.5-turbo" if gpt-4 is not available
    messages=messages,
    max_tokens=300
)
# Print the generated description
description = response.choices[0].message['content'].strip()
print(description)

# Define the data pipeline components
components = {
    "Data Sources": ["MySQL", "REST API"],
    "Data Ingestion": ["Apache Kafka", "Apache Nifi"],
    "Data Storage": ["AWS S3", "Snowflake"],
    "Data Processing": ["Apache Spark", "AWS Lambda"],
    "Data Analytics": ["Tableau", "Power BI"]
}

# Create a graph object
dot = Digraph(comment='Data Pipeline Diagram')

# Add nodes and edges to the graph
for category, items in components.items():
    with dot.subgraph(name=f'cluster_{category}') as c:
        c.attr(label=category)
        c.attr(color='lightgrey')
        for item in items:
            c.node(item)

# Define the flow (edges)
edges = [
    ("MySQL", "Apache Kafka"),
    ("REST API", "Apache Kafka"),
    ("Apache Kafka", "AWS S3"),
    ("Apache Nifi", "Snowflake"),
    ("AWS S3", "Apache Spark"),
    ("Snowflake", "AWS Lambda"),
    ("Apache Spark", "Tableau"),
    ("AWS Lambda", "Power BI")
]

# Add edges to the graph
for edge in edges:
    dot.edge(*edge)

# Render the graph to a file (e.g., a PDF)
dot.render('data_pipeline_diagram', format='pdf')

print(dot.source)  # Print the Graphviz source for verification
