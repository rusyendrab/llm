import ReactFlow, {
  Background,
  BackgroundVariant,
  Controls,
  Edge,
  Node,
} from "reactflow";
import "reactflow/dist/style.css";
import { Box } from "@chakra-ui/react";
import { getInfoFromSchema } from "./SchemaVisualzer.utils";
import { schema } from "./SchemaVisualizer.constants";
import ModelNode from "./ModelNode";

const modelTypes = {
  model: ModelNode
};


// const { models, connections } = getInfoFromSchema(schema);


// let row = 0;
// let column = 0;
// const numModels = models.length;
// let numGrid = 1;

// while (1) {
//   if (numGrid ** 2 >= numModels) {
//     break;
//   }
//   numGrid++;
// }

// const nodes: Node[] = models.map((model, index) => {
//   const x = row * 300;
  
//   if (numGrid % index === 0) {
//     column = 0;
//     row += 1;
//   } else {
//     column += 1;
//   }

//   return {
//     id: model.name,
//     position: { x, y },
//     data: model,
//     type: "model",
//   };
// });

// const edges: Edge[] = connections.map((connection) => {
//   const sourceId = `${connection.source}-${connection.name}`;
//   return {
//     id: sourceId,
//     source: connection.source,
//     target: connection.target,
//     sourceHandle: sourceId,
//     targetHandle: connection.target,
//     animated: true,
//   };
// });



// const nodes_1: Node[] = [
//   {
//     "id": "tableA",
//     "type": "ModelNode",
//     "position": { "x": 0, "y": 0 },
//     "data": { "label": "Table A" },
//     "style": { "width": 100, "height": 6*32 , border: "1px solid black", padding: "1px", backgroundColor: "gray", color:"white" }
//   },
//   { "id": "a.id", "type": "default", "position": { "x": 0, "y": 1*32 }, "data": { "label": "a.id" }, "parentNode": "tableA",  "style": { "textAlign":"center", "width": 100, "height": 32 } },
//   { "id": "a.name", "type": "default", "position": { "x": 0, "y": 2*32 }, "data": { "label": "a.name" }, "parentNode": "tableA",  "style": { "textAlign":"center", "width": 100, "height": 32 } },
//   { "id": "a.age", "type": "default", "position": { "x": 0, "y": 3*32 }, "data": { "label": "a.age" }, "parentNode": "tableA" ,  "style": { "textAlign":"center", "width": 100, "height": 32 }},
//   { "id": "a.city", "type": "default", "position": { "x": 0, "y": 4*32 }, "data": { "label": "a.city" }, "parentNode": "tableA" ,  "style": { "textAlign":"center", "width": 100, "height": 32 }},
//   { "id": "a.country", "type": "default", "position": { "x": 0, "y": 5*32 }, "data": { "label": "a.country" }, "parentNode": "tableA",  "style": { "textAlign":"center", "width": 100, "height": 32 } },
  
//   {
//     "id": "tableB",
//     "type": "ModelNode",
//     "position": { "x": 400, "y": 0 },
//     "data": { "label": "Table B" },
//     "style": { "width": 100, "height": 6*32 , border: "1px solid black", padding: "1px", backgroundColor: "gray", color:"white" }
//   },
//   { "id": "b.id", "type": "default", "position": { "x": 0, "y": 1*32 }, "data": { "label": "b.id" }, "parentNode": "tableB", "style": { "textAlign":"center", "width": 100, "height": 32 }},
//   { "id": "b.name", "type": "default", "position": { "x": 0, "y": 2*32 }, "data": { "label": "b.name" }, "parentNode": "tableB" , "style": { "textAlign":"center", "width": 100, "height": 32 }},
//   { "id": "b.age", "type": "default", "position": { "x": 0, "y": 3*32 }, "data": { "label": "b.age" }, "parentNode": "tableB" , "style": { "textAlign":"center", "width": 100, "height": 32 }},
//   { "id": "b.city", "type": "default", "position": { "x": 0, "y": 4*32 }, "data": { "label": "b.city" }, "parentNode": "tableB" , "style": { "textAlign":"center", "width": 100, "height": 32 }},
//   { "id": "b.country", "type": "default", "position": { "x": 0, "y": 5*32 }, "data": { "label": "b.country" }, "parentNode": "tableB" , "style": { "textAlign":"center", "width": 100, "height": 32 }}
// ];

// const edges_1: Edge[] = [
//   {
//     "id": "a.name-to-b.name",
//     "source": "a.name",
//     "target": "b.name",
//     "animated": true,
//     "label": "a.name → b.name"
//   }
// ];


const nodes: Node[] = [
  // {
  //   id: '1',
  //   type: 'ResizableNode',
  //   data: { label: 'NodeResizer' },
  //   position: { x: -100, y: 50 },
  // },
  // {
  //   id: '2',
  //   type: 'ResizableNodeSelected',
  //   data: { label: 'NodeResizer when selected' },
  //   position: { x: 100, y: 10 },
  // },
  // {
  //   id: '3',
  //   // type: 'CustomResizerNode',
  //   type: 'output',
  //   data: { label: 'Custom Resize Icon' },
  //   position: { x: 250, y: 150 },
  //   style: {
  //     height: 100,
  //   },
  // },
  {
    id: '4',
    type: 'model',
    //data: { label: 'Custom Node' },
    data: {
      name: "User",
      fields: [
        {
          "name":"user_name",
          "type":"string",
          "hasConnections":true,
          "handleType": "source",
          "handlePosition": "right",
        }, 
        {
          "name":"user_email",
          "type":"string",
          "hasConnections":true,
          "handleType": "source",
          "handlePosition": "right",
        }       
        
      ],
      isChild: true
    }, 
    position: { x: 0, y: 0 },
    style: {
      height: 200,
    },
  },
  {
    id: '5',
    type: 'model',
    //data: { label: 'Custom Node' },
    data: {
      name: "Department",
      fields: [
        {
          "name":"department_code",
          "type":"string",
          "hasConnections":true,
          "handleType": "source",
          "handlePosition": "right",
        }, 
        {
          "name":"department_name",
          "type":"string",
          "hasConnections":true,
          "handleType": "source",
          "handlePosition": "right",
        }       
      ],
    }, 
    position: { x: 0, y: 200 },
    style: {
      height: 200,
    },
  }, 
  {
    id: '6',
    type: 'model',
    //data: { label: 'Custom Node' },
    data: {
      name: "UserView",
      fields: [
        {
          "name":"user_name",
          "type":"string",
          "hasConnections":true,
          "handleType": "target",
          "handlePosition": "left",
        }, 
        {
          "name":"user_email",
          "type":"string",
          "hasConnections":true,
          "handleType": "target",
          "handlePosition": "left",
        },
        {
          "name":"department_code",
          "type":"string",
          "hasConnections":true,
          "handleType": "target",
          "handlePosition": "left",
        }, 
        {
          "name":"department_name",
          "type":"string",
          "hasConnections":true,
          "handleType": "target",
          "handlePosition": "left",
        }       
      ],
    }, 
    position: { x: 400, y: 100 },
    style: {
      height: 200,
    },
  }, 

];

const edges: Edge[] = [
  // { id: 'e4-6-name', source: '4',  target: '6', animated: true,label: 'test', type: 'flow' },
  { id: 'e4-6-name', source: '4', sourceHandle:"User-user_name", target: '6', targetHandle: "UserView-user_name", animated: true,label: 'user_name', type: 'flow' },
  { id: 'e4-6-email', source: '4', sourceHandle:"User-user_email", target: '6', targetHandle: "UserView-user_email", animated: true,label: 'user_email', type: 'flow' },
  { id: 'e5-6-department_code', source: '5', sourceHandle:"Department-department_code", target: '6', targetHandle: "UserView-department_code", animated: true,label: 'department_code', type: 'flow' },
  { id: 'e5-6-department_name', source: '5', sourceHandle:"Department-department_name", target: '6', targetHandle: "UserView-department_name", animated: true,label: 'department_name', type: 'flow' },
];
 


export const SchemaVisualizer = () => {
  return (
    <Box height={"100vh"} width="100wh" bg="white" bg1="#1C1c1c">
      <ReactFlow
        defaultNodes={nodes}
        defaultEdges={edges}
        nodeTypes={modelTypes}
        fitView
        fitViewOptions={{ padding: 0.4 }}
        minZoom={0.1}
        maxZoom={20}
        zoomOnScroll={true}
        zoomOnPinch={true}
        zoomOnDoubleClick={true}
        zoomActivationKeyCode={"z"}
      >

        <Background
          variant={BackgroundVariant.Lines}
          gap={10}
          color="#f1f1f1"
          id="1"
        />
        <Background
          variant={BackgroundVariant.Lines}
          gap={50}
          color="#f1f1f1"
          id="2"
        />
        <Background
          variant={BackgroundVariant.Lines}
          gap={100}
          color="#ccc"
          id="3"
        />
        <Background
          variant={BackgroundVariant.Lines}
          gap={200}
          color="#ccc"
          id="4"
        />        
        {/* <Background color="#222" variant={BackgroundVariant.Lines} /> */}
        <Controls />
      </ReactFlow>
    </Box>
  );
};
