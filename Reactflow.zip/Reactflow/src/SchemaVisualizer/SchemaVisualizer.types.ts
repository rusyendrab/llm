export type HandlePosition = 'left' | 'right' | 'top' | 'bottom';
export type HandleType = 'source' | 'target';

export type Model = {
  name: string;
  fields: {
    name: string;
    type: string;
    hasConnections?: boolean;
    handleType: HandleType,
    handlePosition: HandlePosition,

  }[];
  isChild?: boolean;
};

export type ModelConnection = {
  target: string;
  source: string;
  name: string;
};
