export const models = [
            // {
            //   id: '1',
            //   type: 'ResizableNode',
            //   data: { label: 'NodeResizer' },
            //   position: { x: -100, y: 50 },
            // },
            // {
            //   id: '2',
            //   type: 'ResizableNodeSelected',
            //   data: { label: 'NodeResizer when selected' },
            //   position: { x: 100, y: 10 },
            // },
            // {
            //   id: '3',
            //   // type: 'CustomResizerNode',
            //   type: 'output',
            //   data: { label: 'Custom Resize Icon' },
            //   position: { x: 250, y: 150 },
            //   style: {
            //     height: 100,
            //   },
            // },
            {
              id: '4',
              type: 'TableNode',
              //data: { label: 'Custom Node' },
              data: {
                label: "User",
                fields: [
                  {
                    "name":"user_name",
                    "type":"string",
                    "hasConnections":true,
                    "handleType": "source",
                    "handlePosition": "right",
                  }, 
                  {
                    "name":"user_email",
                    "type":"string",
                    "hasConnections":true,
                    "handleType": "source",
                    "handlePosition": "right",
                  }       
                  
                ],
              }, 
              position: { x: 0, y: 270 },
              style: {
                height: 0,
              },
            },
            {
              id: '5',
              type: 'TableNode',
              //data: { label: 'Custom Node' },
              data: {
                label: "Department",
                fields: [
                  {
                    "name":"department_code",
                    "type":"string",
                    "hasConnections":true,
                    "handleType": "source",
                    "handlePosition": "right",
                  }, 
                  {
                    "name":"department_name",
                    "type":"string",
                    "hasConnections":true,
                    "handleType": "source",
                    "handlePosition": "right",
                  }       
                ],
              }, 
              position: { x: 0, y: 470 },
              style: {
                height: 0,
              },
            }, 
            {
              id: '6',
              type: 'TableNode',
              //data: { label: 'Custom Node' },
              data: {
                label: "UserView",
                fields: [
                  {
                    "name":"user_name",
                    "type":"string",
                    "hasConnections":true,
                    "handleType": "target",
                    "handlePosition": "left",
                  }, 
                  {
                    "name":"user_email",
                    "type":"string",
                    "hasConnections":true,
                    "handleType": "target",
                    "handlePosition": "left",
                  },
                  {
                    "name":"department_code",
                    "type":"string",
                    "hasConnections":true,
                    "handleType": "target",
                    "handlePosition": "left",
                  }, 
                  {
                    "name":"department_name",
                    "type":"string",
                    "hasConnections":true,
                    "handleType": "target",
                    "handlePosition": "left",
                  }       
                ],
              }, 
              position: { x: 300, y: 270 },
              style: {
                height: 0,
              },
            }, 
          
          ];
          
export const edges = [
            // { id: 'e4-6-name', source: '4',  target: '6', animated: true,label: 'test', type: 'flow' },
            { id: 'e4-6-name', source: '4', sourceHandle:"User-user_name", target: '6', targetHandle: "UserView-user_name", animated: true,label: 'test', type: 'flow' },
            { id: 'e4-6-email', source: '4', sourceHandle:"User-user_email", target: '6', targetHandle: "UserView-user_email", animated: true,label: 'test', type: 'flow' },
            { id: 'e5-6-department_code', source: '5', sourceHandle:"Department-department_code", target: '6', targetHandle: "UserView-department_code", animated: true,label: 'test', type: 'flow' },
            { id: 'e5-6-department_name', source: '5', sourceHandle:"Department-department_name", target: '6', targetHandle: "UserView-department_name", animated: true,label: 'test', type: 'flow' },
];
